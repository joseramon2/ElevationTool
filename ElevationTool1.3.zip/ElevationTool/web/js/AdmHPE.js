function send_ajax(datos, link, callBack) {
    $.ajax({
        url: link,
        type: 'POST',
        data: datos,
        dataType:"json",
        success: function(text) {
            callBack(text);
        },
        error: function(request, error) {
           console.log([request, error]);
        }
    });
}

function table_consult(){
    send_ajax("action=tableOnShift_consult",'AdmHPEServlet', function(data){
        
        console.log(data);
        
        //btnClickOnShift();
    
        $(function () {
            $('#OnShift').DataTable().clear().draw();
            let info = [];
            //console.log(data);
            for (var i = 0; i < data.length; i++) 
            {
                info = info.concat({
                    0: data[i].Name,
                    1: data[i].Email,
                    2: "GF",
                    3: '<button id="'+data[i].ID+'" type="button" class="btnDisable btn btn-dark">Disable</button>'
                });   
            }
            $('#OnShift').DataTable().rows.add(info).draw();
            btnClickNotScheduled();



        });
    });
}

function table2_consult(){
    //console.log("asdfasdfdsf");
    send_ajax("action=tableNotOnShift_consult",'AdmHPEServlet', function(data){
        console.log(data);
        //table2_consult(data);
        
    
        $(function () {
            $('#NotScheduled').DataTable().clear().draw();
            let info = [];
            //console.log(data);
            for (var i = 0; i < data.length; i++) 
            {
                info = info.concat({
                    0: data[i].Name,
                    1: data[i].Email,
                    2: "GF",
                    3: '<button id="'+data[i].ID+'" type="button" class="btnActive btn btn-dark">Activate</button>'
                });   
            }
            $('#NotScheduled').DataTable().rows.add(info).draw();
            btnClickOnShift();

        });
    });
}

function btnClickOnShift()
{
    $('.btnActive').click(function(){
        //alert(this.id);
        //$('#form_modulos')[0].reset();
        //$('#btn_guardar_mod_sub').val("Guardar").html("Guardar");
        send_ajax("action=setOnShift"+"&ID="+this.id,'AdmHPEServlet', function(data){
            console.log(data);
            //table2_consult(JSON.parse(data));
            table_consult();
            table2_consult();
            
        });
        
        
        
    });
}

function btnClickNotScheduled()
{
    $('.btnDisable').click(function(){
        //alert(this.id);
        //$('#form_modulos')[0].reset();
        //$('#btn_guardar_mod_sub').val("Guardar").html("Guardar");
        send_ajax("action=setNotScheduled"+"&ID="+this.id,'AdmHPEServlet', function(data){
            console.log(data);
            table_consult();
            table2_consult();
            

        });
        
        
    });
}

$(document).ready(function() 
{
    $('#OnShift').DataTable();
    $('#NotScheduled').DataTable();
    
    
    table_consult();
        //btnClickOnShift();

    
    table2_consult();
        

} );
