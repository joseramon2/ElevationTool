function send_ajax(datos, link, callBack) {
    $.ajax({
        url: link,
        type: 'POST',
        data: datos,
        dataType:"json",
        success: function(text) {
            callBack(text);
        },
        error: function(request, error) {
           console.log([request, error]);
        }
    });
}

function DeleteRow(){
    $('#myTableRow').remove();
    
};
   

function AddRow()
{
    $('#myTable').children('tbody').append('<tr></td>Algo</td></tr>'); 
};

var tbody = $('#myTable').children('tbody');
var table = tbody.length ? tbody : $('#myTable');
var row = '<tr>'+
    "'<td contenteditable='true'>{{id}}</td>'"+
    "'<td contenteditable='true'>{{name}}</td>'"+
    "'<td contenteditable='true'>{{phone}}</td>"+
'</tr>';


//Add row


$(document).ready(function() 
{
    table.append(row.compose({
        'id': 3,
        'name': 'Lee',
        'phone': '123 456 789'
    }));
        

} );