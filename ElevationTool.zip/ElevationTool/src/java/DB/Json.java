/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

import com.google.gson.Gson;
import org.json.JSONArray;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

public class Json {
    public String ListToArrayJson(List<Map<String, String>> list){
        String json = new Gson().toJson(list);
        return json;
    }

    public JSONArray ArrayJsonToList(String parameter) throws JSONException {
        JSONArray list = new JSONArray(parameter);
        return list;
    }
}