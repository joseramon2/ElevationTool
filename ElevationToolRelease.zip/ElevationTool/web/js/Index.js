function send_ajax(datos, link, callBack) {
    $.ajax({
        url: link,
        type: 'POST',
        data: datos,
        dataType:"json",
        success: function(text) {
            callBack(text);
        },
        error: function(request, error) {
           console.log([request, error]);
        }
    });
}

function ClickCompany()
{
   $(".btnSelectCompany").click(function() {
    var a= this.id;
    switch(a) {
        case "btnHPI":
            tableHPI();
            break;
        case "btnHPE":
            tableHPE();
            break;
        case "btnDXC":
            tableDXC();
            break;
        case "btnMF":
            tableMF();
            break;
        default:
            
    } 

    });
};


function tableHPI(){
    send_ajax("action=HPITAble",'IndexServlet', function(data){
        
        //console.log(data);
        
        //btnClickOnShift();
    
        $(function () {
            $('#dataTable').DataTable().clear().draw();
            let info = [];
            //console.log(data);
            for (var i = 0; i < data.length; i++) 
            {
                info = info.concat({
                    0: "RED",
                    1: data[i].Name,
                    2: data[i].Email,
                    3: data[i].NW,
                    4: data[i].Elevation,
                    5: data[i].MIs,
                    6: '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnELE" value="ElePlus">EL +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnELE" value="EleLess">EL -</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnMI" value="MIPlus">MI +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnMI" value="MILess">MI -</button>'
                });   
            }
            $('#dataTable').DataTable().rows.add(info).draw();
            Ele_MIs_HPI();
        });
    });
}
function tableHPE(){
    send_ajax("action=HPETAble",'IndexServlet', function(data){
        
        console.log(data);
        
        //btnClickOnShift();
    
        $(function () {
            $('#dataTable').DataTable().clear().draw();
            let info = [];
            //console.log(data);
            for (var i = 0; i < data.length; i++) 
            {
                info = info.concat({
                    0: "RED",
                    1: data[i].Name,
                    2: data[i].Email,
                    3: data[i].NW,
                    4: data[i].Elevation,
                    5: data[i].MIs,
                    6: '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnELEHPE" value="ElePlus">EL +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnELEHPE" value="EleLess">EL -</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnMIHPE" value="MIPlus">MI +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnMIHPE" value="MILess">MI -</button>'
                });   
            }
            $('#dataTable').DataTable().rows.add(info).draw();
            Ele_MIs_HPE();
        });
    });
}
function tableDXC(){
    send_ajax("action=DXCTAble",'IndexServlet', function(data){
        
        console.log(data);
        
        //btnClickOnShift();
    
        $(function () {
            $('#dataTable').DataTable().clear().draw();
            let info = [];
            //console.log(data);
            for (var i = 0; i < data.length; i++) 
            {
                info = info.concat({
                    0: "RED",
                    1: data[i].Name,
                    2: data[i].Email,
                    3: data[i].NW,
                    4: data[i].Elevation,
                    5: data[i].MIs,
                    6: '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnELE">EL +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnELE">EL -</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnMI">MI +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnMI">MI -</button>'
                });   
            }
            $('#dataTable').DataTable().rows.add(info).draw();
        });
    });
}
function tableMF(){
    send_ajax("action=MFTAble",'IndexServlet', function(data){
        
        console.log(data);
        
        //btnClickOnShift();
    
        $(function () {
            $('#dataTable').DataTable().clear().draw();
            let info = [];
            //console.log(data);
            for (var i = 0; i < data.length; i++) 
            {
                info = info.concat({
                    0: "RED",
                    1: data[i].Name,
                    2: data[i].Email,
                    3: data[i].NW,
                    4: data[i].Elevation,
                    5: data[i].MIs,
                    6: '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnELE">EL +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnELE">EL -</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-light btnMI">MI +</button>'+
                         '<button id="'+data[i].ID+'" type="button" class="btn btn-dark btnMI">MI -</button>'
                });   
            }
            $('#dataTable').DataTable().rows.add(info).draw();
        });
    });
}

function Ele_MIs_HPI()
{
    $('.btnELE').click(function(){
        var idd = this.id;
        var val = $(this).attr("value");
        console.log(idd);
        console.log(val);
        send_ajax("action=Elevation&ID="+idd+"&VAL="+val,'IndexServlet', function(data)
        {
            //console.log(data);
            tableHPI();
        });
        
    });
    $('.btnMI').click(function(){
        //alert("MISSSSS");
        var idd = this.id;
        var val = $(this).attr("value");
        //console.log(idd);
        //console.log(val);
        send_ajax("action=MIs&ID="+idd+"&VAL="+val,'IndexServlet', function(data)
        {
            console.log(data);
            tableHPI();
        });
        
    });
};

function Ele_MIs_HPE()
{
    $('.btnELEHPE').click(function(){
        var idd = this.id;
        var val = $(this).attr("value");
        console.log(idd);
        console.log(val);
        send_ajax("action=Elevation&ID="+idd+"&VAL="+val,'IndexServlet', function(data)
        {
            //console.log(data);
            tableHPE();
        });
        
    });
    $('.btnMIHPE').click(function(){
        //alert("MISSSSS");
        var idd = this.id;
        var val = $(this).attr("value");
        //console.log(idd);
        //console.log(val);
        send_ajax("action=MIs&ID="+idd+"&VAL="+val,'IndexServlet', function(data)
        {
            console.log(data);
            tableHPE();
        });
        
    });
};

$(document).ready(function() 
{
    ClickCompany();
        

} );