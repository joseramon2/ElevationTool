function send_ajax(datos, link, callBack) {
    $.ajax({
        url: link,
        type: 'POST',
        data: datos,
        dataType:"json",
        success: function(text) {
            callBack(text);
        },
        error: function(request, error) {
           console.log([request, error]);
        }
    });
}

$('.btnMIHPE').click(function(){
        //alert("MISSSSS");
        var idd = this.id;
        var val = $(this).attr("value");
        //console.log(idd);
        //console.log(val);
        send_ajax("action=btnLogout",'LogoutServlet', function(data)
        {
            console.log(data);

        });
        
    });
    
$(document).ready(function() 
{
   
        

} );