package DB;

//new conexion();

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion{ 
    
    /*public static void main(String[] args) {
        Conexion con = new Conexion();
        System.out.println(con.Error);
    }*/
    /*private static final String DRIVER = "com.mysql.jdbc.Driver";     
    private static final String URL = "jdbc:mysql://localhost:3306/mrplumer"; 
    private static final String USERNAME = "root";   
    private static final String PASSWORD = "";*/
    
    private static final String DRIVER = "org.mariadb.jdbc.Driver";     
    private static final String URL = "jdbc:mariadb://localhost:3306/BLUES"; 
    private static final String USERNAME = "root";   
    private static final String PASSWORD = "jose_21";
    
    /*private static final String DRIVER = "com.mysql.jdbc.Driver";     
    private static final String URL = "jdbc:mysql://t89yihg12rw77y6f.cbetxkdyhwsb.us-east-1.rds.amazonaws.com:3306/t836uopkeinehoia"; 
    private static final String USERNAME = "b05z1rvhwv35tbif";   
    private static final String PASSWORD = "nyhpok6fe7yck1ya";*/
    
    public String Error = "";
    public Connection connection = null;
    public PreparedStatement ps;
    private ResultSet rs = null;
    
    private static Connection getConnection() throws SQLException{   
        try {   
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL+"?user="+USERNAME+"&password="+PASSWORD+"&zeroDateTimeBehavior=convertToNull");
        } catch (ClassNotFoundException ex) {   
            System.out.println("Where is your SQL JDBC Driver? "   
            + "Include in your library path!");   
            return null;   
        }
    }

    public Conexion(){     
        try {
            connection = getConnection();   
        } catch (SQLException ex) {
            Error = "Connection Failed! Check output console";
        }   
        if (connection != null) {
            Error = "You made it, take control your database now!";
        } else {
            Error = "Failed to make connection!";
        }
    }
    
    public void CloseUpdate(){
        try {
            connection.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Close(){
        try {
            connection.close();
            ps.close();
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public int QueryToNumber() throws SQLException
    {
        //String cont="";
        int a = 0;
        try{
            while(rs.next()){ 
                a = rs.getInt(1);    
            }
            return a;
        }
        catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
    }
    public String QueryToString(String Name) throws SQLException
    {
        //String cont="";
        String r = "";
        try{
            while(rs.next()){ 
                r = rs.getString(Name);    
            }
            return r;
        }
        catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
            return "";
        }
    }
    public List<Map<String, String>> QueryToList(){
        List<Map<String, String>> list = new ArrayList<>();
        try {
            while(rs.next()){
                Map<String, String> options = new LinkedHashMap<>();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    options.put(rs.getMetaData().getColumnLabel(i), rs.getString(i));
                }
                list.add(options);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public void prepareStatement(String query){
        try {
            ps = connection.prepareStatement(query);
        } catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void executeQuery(){        
        try {
            rs = ps.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public int executeUpdate(){        
        try {
            int rs = ps.executeUpdate();
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
}
