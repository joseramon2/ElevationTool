/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import DB.Conexion;
import DB.Json;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author majosera
 */
public class IndexServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        HttpSession session = request.getSession();
        
        if("HPITAble".equals(request.getParameter("action")))
            {
                //System.out.println("sakdnfasnervaowieurimnoun");
                Conexion objConexion = new Conexion();
                objConexion.prepareStatement("Select ID, Name, Email, NW, Elevation, MIs  from EngineerOnDuty where Company = \"HPI\" and OnDutyFlag = 1;");
                objConexion.executeQuery();

                Json j = new Json();
                //"{\"respuesta\":\"Exito\"}"
                //j.ListToArrayJson(objConexion.QueryToList())
                response.getWriter().print(j.ListToArrayJson(objConexion.QueryToList()));
                objConexion.Close();
            }
            else if("HPETAble".equals(request.getParameter("action")))
            {
                //System.out.println("sakdnfasnervaowieurimnoun");
                Conexion objConexion = new Conexion();
                objConexion.prepareStatement("Select ID, Name, Email, NW, Elevation, MIs  from EngineerOnDuty where Company = \"HPE\" and OnDutyFlag = 1;");
                objConexion.executeQuery();

                Json j = new Json();
                //"{\"respuesta\":\"Exito\"}"
                //j.ListToArrayJson(objConexion.QueryToList())
                response.getWriter().print(j.ListToArrayJson(objConexion.QueryToList()));
                objConexion.Close();
            }
            else if("DXCTAble".equals(request.getParameter("action")))
            {
                //System.out.println("sakdnfasnervaowieurimnoun");
                Conexion objConexion = new Conexion();
                objConexion.prepareStatement("Select ID, Name, Email, NW, Elevation, MIs  from EngineerOnDuty where Company = \"DXC\" and OnDutyFlag = 1;");
                objConexion.executeQuery();

                Json j = new Json();
                //"{\"respuesta\":\"Exito\"}"
                //j.ListToArrayJson(objConexion.QueryToList())
                response.getWriter().print(j.ListToArrayJson(objConexion.QueryToList()));
                objConexion.Close();
            }
            else if("MFTAble".equals(request.getParameter("action")))
            {
                //System.out.println("sakdnfasnervaowieurimnoun");
                Conexion objConexion = new Conexion();
                objConexion.prepareStatement("Select ID, Name, Email, NW, Elevation, MIs  from EngineerOnDuty where Company = \"MF\" and OnDutyFlag = 1;");
                objConexion.executeQuery();

                Json j = new Json();
                //"{\"respuesta\":\"Exito\"}"
                //j.ListToArrayJson(objConexion.QueryToList())
                response.getWriter().print(j.ListToArrayJson(objConexion.QueryToList()));
                objConexion.Close();
            }
            else if("Elevation".equals(request.getParameter("action")))
            {
                
                Conexion objConexion = new Conexion();
                String ID = request.getParameter("ID");
                //System.out.println(request.getParameter("VAL"));
                int Cont = 0;
                try {
                    objConexion.prepareStatement("Select Elevation from EngineerOnDuty where ID=?;");
                    objConexion.ps.setString(1, ID);
                    objConexion.executeQuery();
                    Cont = objConexion.QueryToNumber();
                    //System.out.println(Cont);
                    //objConexion.Close();
                    switch(request.getParameter("VAL"))
                    {
                        case "ElePlus":
                            Cont = Cont +1;
                            break;
                        case "EleLess":
                            Cont = Cont - 1;
                            if(Cont <=0)
                                Cont = 0;
                            break;
                        
                    }
                    objConexion.prepareStatement("UPDATE engineeronduty SET Elevation=? WHERE  ID=?;");
                    objConexion.ps.setString(1, Integer.toString(Cont));
                    objConexion.ps.setString(2, ID);
                    objConexion.executeUpdate(); 
                    //Json j = new Json();
                //"{\"respuesta\":\"Exito\"}"
                //j.ListToArrayJson(objConexion.QueryToList())
                    response.getWriter().print("{\"Cont\":\""+Integer.toString(Cont +1)+"\"}");
                    
                } 
                catch (SQLException ex) {
                    Logger.getLogger(AdmHPIServlet.class.getName()).log(Level.SEVERE, null, ex);
                    response.getWriter().print("{\"Cont\":\"-1\"}");
                }
                //objConexion.prepareStatement("UPDATE `blues`.`engineeronduty` SET `Elevation`='1' WHERE  `ID`=?;");
                //objConexion.executeQuery();

               
                
            }
            
            else if("MIs".equals(request.getParameter("action")))
            {
                
                Conexion objConexion = new Conexion();
                String ID = request.getParameter("ID");
                //System.out.println(request.getParameter("VAL"));
                int Cont = 0;
                try {
                    objConexion.prepareStatement("Select MIs from EngineerOnDuty where ID=?;");
                    objConexion.ps.setString(1, ID);
                    objConexion.executeQuery();
                    Cont = objConexion.QueryToNumber();
                    //System.out.println(Cont);
                    //objConexion.Close();
                    switch(request.getParameter("VAL"))
                    {
                        case "MIPlus":
                            Cont = Cont +1;
                            break;
                        case "MILess":
                            Cont = Cont - 1;
                            if(Cont <=0)
                                Cont = 0;
                            break;
                        
                    }
                    objConexion.prepareStatement("UPDATE engineeronduty SET MIs=? WHERE  ID=?;");
                    objConexion.ps.setString(1, Integer.toString(Cont));
                    objConexion.ps.setString(2, ID);
                    objConexion.executeUpdate(); 
                    //Json j = new Json();
                //"{\"respuesta\":\"Exito\"}"
                //j.ListToArrayJson(objConexion.QueryToList())
                    response.getWriter().print("{\"Cont\":\""+Integer.toString(Cont +1)+"\"}");
                    
                } 
                catch (SQLException ex) {
                    Logger.getLogger(AdmHPIServlet.class.getName()).log(Level.SEVERE, null, ex);
                    response.getWriter().print("{\"Cont\":\"-1\"}");
                }
                //objConexion.prepareStatement("UPDATE `blues`.`engineeronduty` SET `Elevation`='1' WHERE  `ID`=?;");
                //objConexion.executeQuery();

               
                
            }
    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
